# AV_Ultimate_Student_Hunt
Solution for the Ultimate Student Hunt Challenge.
